<!DOCTYPE html>
<html>

<head>
    <title>Contact Us</title>
</head>

<body>
    <h1>Contact Us</h1>
    <p>This is the about page.</p>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\pemrogramweb\resources\views/contact.blade.php ENDPATH**/ ?>