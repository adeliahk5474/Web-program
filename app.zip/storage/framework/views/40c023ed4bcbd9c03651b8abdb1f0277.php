<!DOCTYPE html>
<html>

<head>
    <title>Service Us</title>
</head>

<body>
    <h1>Service Us</h1>
    <p>This is the about page.</p>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\pemrogramweb\resources\views/service.blade.php ENDPATH**/ ?>