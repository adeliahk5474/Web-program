<!DOCTYPE html>
<html>

<head>
    <title>About Us</title>
</head>

<body>
    <h1>About Us</h1>
    <p>This is the about page.</p>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\pemrogramweb\resources\views/about.blade.php ENDPATH**/ ?>