<!DOCTYPE html>
<html>

<head>
    <title>Picture Us</title>
</head>

<body>
    <h1>Picture Us</h1>
    <p>This is the about page.</p>
</body>

</html>
